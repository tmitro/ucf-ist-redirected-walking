﻿using UnityEngine;
using System.Collections;

public class NullRedirector : Redirector
{

    public override void ApplyRedirection()
    {

    }
}
